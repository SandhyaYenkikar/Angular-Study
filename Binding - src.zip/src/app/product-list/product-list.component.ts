import { Component } from '@angular/core';

@Component({
  selector: 'app-product-list',
  standalone: false,
  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.css'
})
export class ProductListComponent {

  // name:string = "IPhone 13";
  // price: number = 100;
  // color: string="Black";
  // discountPrice:number = 90;

  //declare product object
  product=  {
    name: "IPhone",
    price: 999,
    color:"red",
    discountPrice:888,
    val: 789.5689,
    available:10
  }
//val: any;
  getOriginalPrice (){
    return this.product.price - this.product.discountPrice
  }
}
