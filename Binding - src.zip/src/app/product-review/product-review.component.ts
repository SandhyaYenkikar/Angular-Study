import { Component } from '@angular/core';

@Component({
  selector: 'app-product-review',
  standalone: false,
  templateUrl: './product-review.component.html',
  styleUrl: './product-review.component.css'
})
export class ProductReviewComponent {
  reviews = {
    product1: "Good",
    product2: "Very Good",
    product3: "Average",
    product4: "Bad",
    product5: "Fine",
  }

}
