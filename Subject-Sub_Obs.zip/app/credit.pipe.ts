import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'credit',
  standalone: false
})
export class CreditPipe implements PipeTransform {

  transform(value: string): string {
    if (!value) {
      return value;
    }

    const masked=value.slice(0,-4).replace(/./g,'*')
    const visible=value.slice(-4)
    return `${masked}${visible}`
  }

}

