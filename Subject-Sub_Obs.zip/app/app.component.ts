import { Component } from '@angular/core';
import { BehaviorSubject, from, Observable, of } from 'rxjs';
import { Subject } from 'rxjs';
import { ReplaySubject } from 'rxjs';
import { AsyncSubject } from 'rxjs';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  standalone: false,
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'Angular_6_2';

  //RxJS
  //example 1
  // myObservable = new Observable<string>(observer => {
  //   observer.next("Hello");
  //   observer.next("Sandhya!");
  //   observer.next("How are you.");
  //   observer.complete();
  // });
  
  // constructor(){
  //   this.myObservable.subscribe(value => console.log(value));
  // }

  //example 2
  // observer={
  //   next:(value:any)=> console.log("Received", value),
  //   error:(err:any)=>console.log("error",err),
  //   complete:()=>console.log("Done!")
  // }
  // observable= new Observable<number>(obs=>{
  //   obs.next(1),
  //   obs.next(2),
  //   obs.complete()
  // })

  // constructor(){
  //   this.observable.subscribe(this.observer);
  // }

  //example 3
  // myObservable = new Observable<string>(observer => {
  //   setTimeout(()=>observer.next("Hello"),1000);
  //   setTimeout(()=>observer.next("Sandhya!"),2000);
  //   setTimeout(()=>observer.complete(),3000);

  // });
  
  // constructor(){
  //   this.myObservable.subscribe(value => console.log(value));
  // }

  //example 4
  // observable= new Observable<number>(obs=>{
  //   setTimeout(()=>obs.next(1),1000);
  //   setTimeout(()=>obs.next(2),2000);
  //   setTimeout(()=>obs.complete(),3000);
  // })

  // constructor(){
  // const subscription=this.observable.subscribe({next:(value:any)=> console.log("Received", value),
  //   error:(err:any)=>console.log("error",err),
  //   complete:()=>console.log("Done!")}
  // );

  // setTimeout(()=>{subscription.unsubscribe(),
  //   console.log("Unsubscribed!")
  // },4000)
  // }

  //example 5
//   orderStatusObservable= new Observable<string>
//   subscription:any;
//   statuses: string[] = [];
//   flag:boolean=false

//   customObserver = {
//     next: (status: string) => {
//       console.log("Order Status: ", status);
//       this.statuses.push(status);
//     },
//     error: (err: any) => {
//       console.log("Error: ", err);
//       this.statuses.push(`Error: ${err}`);
//     },
//     complete: () => {
//       console.log("Order tracking completed!");
//       this.statuses.push("Order tracking completed!");
//     }
//   };

//   ngOnInit() {
//     this.orderStatusObservable = new Observable(observer => {
//       observer.next('Order placed');
//       setTimeout(() => observer.next("Shipped"), 2000);
//       setTimeout(() => observer.next("Out for Delivery"), 4000);
//       setTimeout(() => observer.next("Delivered"), 6000);
//       setTimeout(() => observer.complete(), 6000);
//     });

//     this.subscription = this.orderStatusObservable.subscribe(this.customObserver);

// //       setTimeout(() => {
// //         this.subscription.unsubscribe();
// //         console.log("Unsubscribed!");
// //         this.statuses.push("Unsubscribed!");
// //       }, 8000);
// // }

// //   unsubscribe() {
// //     this.subscription.unsubscribe();
// //     console.log("Unsubscribed!");
// //     this.statuses.push("Unsubscribed!");
// //   }
// // }

//       setTimeout(() => {
//         this.subscription.unsubscribe();
//         console.log("Unsubscribed!");
//         this.statuses.push("Unsubscribed!");
//       }, 8000);
// }

//   unsubscribe() {
//     this.subscription.unsubscribe();
//     console.log("Unsubscribed!");
//     this.statuses.push("Unsubscribed!");
//   }


//Subject
  // subject= new Subject<number>();

  // constructor() {
  //   //this.subject = new Subject<number>();

  //   this.subject.subscribe((value: number) => console.log('Observer 1',value));
  //   this.subject.subscribe((value: number) => console.log('Observer 2',value));
  //   this.subject.next(1);
  //   this.subject.next(2);

  // }

//Behaviour Subject
  
//   behavioursubject = new BehaviorSubject<number>(0); // initialized with a default value

//   constructor() {
//     this.behavioursubject.subscribe((value: number) => console.log('Observer 1', value));
//     this.behavioursubject.subscribe((value: number) => console.log('Observer 2', value));
//     this.behavioursubject.next(1);
//     this.behavioursubject.next(2);
//   }
// 

//Reply Subject
// replysubject = new ReplaySubject<number>(2); 

//   constructor() {
//     this.replysubject.subscribe((value: number) => console.log('Observer 1', value));
//     this.replysubject.subscribe((value: number) => console.log('Observer 2', value));
//     this.replysubject.next(1);
//     this.replysubject.next(2);
//   }

//Async Subject
// asyncsubject = new AsyncSubject<number>(); 

// constructor() {
//   this.asyncsubject.subscribe((value: number) => console.log('Observer 1', value));
//   this.asyncsubject.subscribe((value: number) => console.log('Observer 2', value));
//   this.asyncsubject.next(1);
//   this.asyncsubject.next(2);
//   this.asyncsubject.complete(); 
// }


}
